

var ohanstBalanceInput= (function () {

    "use strict";
   
    var nstBalanceInput= function (NumCompte, IntitulCompte, SoldeDebit,SoldeCredit) {   
      //  var _arrnstBalanceInputs = require('./_arrnstBalanceInputs');
  var _arrnstBalanceInputs=[];
  var DetailCount = 0;
        var TotalSoldeDebit = 0;
        var TotalSoldeCredit = 0;
   _arrnstBalanceInputs.slice().push({
           "NumCompte":NumCompte,
           "IntitulCompte":IntitulCompte,
           "SoldeDebit":SoldeDebit,
           "SoldeCredit":SoldeCredit
        });     
        
        this.addbalanceinput=function(){
            _arrnstBalanceInputs.push(
                {
            "NumCompte":NumCompte,
           "IntitulCompte":IntitulCompte,
           "SoldeDebit":SoldeDebit,
           "SoldeCredit":SoldeCredit
                }
            );
            TotalSoldeDebit += SoldeDebit;
            TotalSoldeCredit += SoldeCredit;
            DetailCount = _arrnstBalanceInputs.length;

            return {
                TotalSoldeDebit: TotalSoldeDebit,
                TotalSoldeCredit: TotalSoldeCredit,
                DetailCount: DetailCount,
            };
        }

        this.getData = function () {
            return {
                /*  "NumCompte":NumCompte,
           "IntitulCompte":IntitulCompte,
           "SoldeDebit":SoldeDebit,
           "SoldeCredit":SoldeCredit, */
           "TotalSoldeDebit": TotalSoldeDebit,
                "TotalSoldeCredit": TotalSoldeCredit,
                "DetailCount": DetailCount,
        "_arrnstBalanceInputs": _arrnstBalanceInputs.slice()
            };
        };
      
    };
    
     return {
         nstBalanceInput:nstBalanceInput
     }

      
})();
   
    var stBalanceInputtest = new ohanstBalanceInput.stBalanceInput("85520", "Mensah", 90000,0)
     var stBalanceInputtest1 = new ohanstBalanceInput.stBalanceInput("78520", "Akoli", 0, 150000)
   stBalanceInputtest.addbalanceinput("58520", "Mensah", 90000, 0)
    stBalanceInputtest1.addbalanceinput("58520", "Mensah", 90000, 0)
    // stBalanceInputtest._arrnstBalanceInputs.getData()

//_arrnstBalanceInputs=[stBalanceInputtest,stBalanceInputtest1]
      //  stBalanceInputtest("58520", "Mensah", 90000, 0)
    
   console.log(stBalanceInputtest.getData());
   //console.log(stBalanceInputtest1.getData());
       //console.log(stBalanceInputtest._arrnstBalanceInputs.getData());
